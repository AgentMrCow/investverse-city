// components/ClubWar.js - Club War Component
import React, { useState, useEffect } from 'react';
import './ClubWar.css';

const ClubWar = ({ userTokens }) => {
  const [warActive, setWarActive] = useState(true);
  const [warTime, setWarTime] = useState(120); // 2 hours in minutes
  const [teamATokens, setTeamATokens] = useState(5000);
  const [teamBTokens, setTeamBTokens] = useState(5000);
  const [teamAHealth, setTeamAHealth] = useState(100);
  const [teamBHealth, setTeamBHealth] = useState(100);
  const [userTeam, setUserTeam] = useState('A');
  const [buildings, setBuildings] = useState([
    { id: 1, team: 'A', type: 'HQ', health: 100, position: { x: 10, y: 50 } },
    { id: 2, team: 'A', type: 'Tower', health: 80, position: { x: 30, y: 30 } },
    { id: 3, team: 'A', type: 'Factory', health: 60, position: { x: 20, y: 70 } },
    { id: 4, team: 'B', type: 'HQ', health: 100, position: { x: 90, y: 50 } },
    { id: 5, team: 'B', type: 'Tower', health: 80, position: { x: 70, y: 30 } },
    { id: 6, team: 'B', type: 'Factory', health: 60, position: { x: 80, y: 70 } },
  ]);
  const [availableWeapons, setAvailableWeapons] = useState([
    { id: 1, name: 'Basic Sword', damage: 10, cost: 50, type: 'attack' },
    { id: 2, name: 'ESG Shield', damage: 0, defense: 20, cost: 100, type: 'defense' },
    { id: 3, name: 'Crypto Cannon', damage: 30, cost: 200, type: 'attack' },
    { id: 4, name: 'Risk Bow', damage: 15, cost: 75, type: 'attack' },
    { id: 5, name: 'Diversification Armor', defense: 40, cost: 150, type: 'defense' },
  ]);
  const [selectedWeapon, setSelectedWeapon] = useState(null);
  const [warLog, setWarLog] = useState([]);

  useEffect(() => {
    if (warActive && warTime > 0) {
      const timer = setInterval(() => {
        setWarTime(prev => prev - 1);
      }, 1000); // Update every minute in real app
      return () => clearInterval(timer);
    } else if (warTime <= 0) {
      endWar();
    }
  }, [warActive, warTime]);

  const formatTime = (minutes) => {
    const hrs = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hrs}h ${mins}m`;
  };

  const attackBuilding = (buildingId) => {
    if (!selectedWeapon || selectedWeapon.type !== 'attack') {
      alert('Select an attack weapon first!');
      return;
    }

    if (userTokens < selectedWeapon.cost) {
      alert('Not enough tokens!');
      return;
    }

    const building = buildings.find(b => b.id === buildingId);
    if (!building || building.team === userTeam) {
      alert('Cannot attack your own team!');
      return;
    }

    // Update building health
    const updatedBuildings = buildings.map(b => 
      b.id === buildingId 
        ? { ...b, health: Math.max(0, b.health - selectedWeapon.damage) }
        : b
    );
    setBuildings(updatedBuildings);

    // Update team health
    const totalTeamHealth = updatedBuildings
      .filter(b => b.team === (userTeam === 'A' ? 'B' : 'A'))
      .reduce((sum, b) => sum + b.health, 0);
    
    if (userTeam === 'A') {
      setTeamBHealth(totalTeamHealth / 3); // Normalize to 100
    } else {
      setTeamAHealth(totalTeamHealth / 3);
    }

    // Deduct tokens
    const newTokens = userTokens - selectedWeapon.cost;

    // Add to war log
    const newLog = {
      time: new Date().toLocaleTimeString(),
      action: `${userTeam === 'A' ? 'Team A' : 'Team B'} attacked building ${buildingId} with ${selectedWeapon.name}`,
      damage: selectedWeapon.damage
    };
    setWarLog([newLog, ...warLog.slice(0, 9)]);

    // Award tokens to team if building destroyed
    if (updatedBuildings.find(b => b.id === buildingId).health <= 0) {
      const reward = 100;
      if (userTeam === 'A') {
        setTeamATokens(prev => prev + reward);
      } else {
        setTeamBTokens(prev => prev + reward);
      }
      
      setWarLog(prev => [
        {
          time: new Date().toLocaleTimeString(),
          action: `🚨 Building ${buildingId} destroyed! +${reward} tokens to ${userTeam === 'A' ? 'Team A' : 'Team B'}`,
          damage: 0
        },
        ...prev.slice(0, 9)
      ]);
    }

    alert(`Attacked building ${buildingId} for ${selectedWeapon.damage} damage!`);
  };

  const purchaseWeapon = (weapon) => {
    if (userTokens >= weapon.cost) {
      setSelectedWeapon(weapon);
      alert(`Selected ${weapon.name}! Ready to attack.`);
    } else {
      alert('Not enough tokens!');
    }
  };

  const endWar = () => {
    setWarActive(false);
    const winner = teamAHealth > teamBHealth ? 'A' : 'B';
    alert(`⚔️ War Ended! Team ${winner} wins!`);
  };

  const joinWar = (team) => {
    setUserTeam(team);
    alert(`Joined Team ${team}!`);
  };

  return (
    <div className="club-war">
      <div className="war-header">
        <h2>⚔️ Club War - Financial Conquest</h2>
        <div className="war-timer">
          ⏰ War Ends In: {formatTime(warTime)}
          {!warActive && <span className="war-status">🔴 War Ended</span>}
        </div>
      </div>

      <div className="war-teams">
        <div className="team team-a">
          <h3>Team A: Crypto Kings</h3>
          <div className="team-stats">
            <div className="health-bar">
              <div className="health-fill" style={{ width: `${teamAHealth}%` }}></div>
              <span>Health: {teamAHealth}%</span>
            </div>
            <div className="token-count">🎫 {teamATokens} Tokens</div>
            <div className="members">👥 24 Members</div>
          </div>
          <button 
            className={`join-btn ${userTeam === 'A' ? 'joined' : ''}`}
            onClick={() => joinWar('A')}
            disabled={userTeam === 'A'}
          >
            {userTeam === 'A' ? '✅ Joined' : 'Join Team'}
          </button>
        </div>

        <div className="vs-badge">VS</div>

        <div className="team team-b">
          <h3>Team B: ESG Warriors</h3>
          <div className="team-stats">
            <div className="health-bar">
              <div className="health-fill" style={{ width: `${teamBHealth}%` }}></div>
              <span>Health: {teamBHealth}%</span>
            </div>
            <div className="token-count">🎫 {teamBTokens} Tokens</div>
            <div className="members">👥 22 Members</div>
          </div>
          <button 
            className={`join-btn ${userTeam === 'B' ? 'joined' : ''}`}
            onClick={() => joinWar('B')}
            disabled={userTeam === 'B'}
          >
            {userTeam === 'B' ? '✅ Joined' : 'Join Team'}
          </button>
        </div>
      </div>

      {/* Battle Map */}
      <div className="battle-map">
        <h3>🗺️ Battle Map</h3>
        <div className="map-container">
          {buildings.map(building => (
            <div
              key={building.id}
              className={`building ${building.team} ${building.type.toLowerCase()}`}
              style={{
                left: `${building.position.x}%`,
                top: `${building.position.y}%`,
                opacity: building.health / 100
              }}
              onClick={() => warActive && attackBuilding(building.id)}
            >
              <div className="building-icon">
                {building.type === 'HQ' ? '🏰' : 
                 building.type === 'Tower' ? '🏯' : '🏭'}
              </div>
              <div className="building-health">{building.health}%</div>
            </div>
          ))}
          <div className="territory-line"></div>
        </div>
      </div>

      <div className="war-interface">
        <div className="weapon-shop">
          <h3>🛒 Weapon Shop</h3>
          <p>Your Tokens: 🎫 {userTokens}</p>
          <div className="weapons-grid">
            {availableWeapons.map(weapon => (
              <div 
                key={weapon.id}
                className={`weapon-card ${selectedWeapon?.id === weapon.id ? 'selected' : ''}`}
                onClick={() => purchaseWeapon(weapon)}
              >
                <div className="weapon-icon">
                  {weapon.type === 'attack' ? '⚔️' : '🛡️'}
                </div>
                <h4>{weapon.name}</h4>
                {weapon.damage > 0 && <div>Damage: {weapon.damage}</div>}
                {weapon.defense > 0 && <div>Defense: +{weapon.defense}%</div>}
                <div className="weapon-cost">🎫 {weapon.cost}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="war-log">
          <h3>📜 Battle Log</h3>
          <div className="log-entries">
            {warLog.length > 0 ? (
              warLog.map((entry, index) => (
                <div key={index} className="log-entry">
                  <span className="log-time">[{entry.time}]</span>
                  <span className="log-action">{entry.action}</span>
                  {entry.damage > 0 && (
                    <span className="log-damage">-{entry.damage}HP</span>
                  )}
                </div>
              ))
            ) : (
              <div className="no-logs">No battle activity yet...</div>
            )}
          </div>
        </div>
      </div>

      {warActive && selectedWeapon && (
        <div className="selected-weapon">
          <strong>Selected:</strong> {selectedWeapon.name} 
          <span className="weapon-stats">
            {selectedWeapon.damage > 0 && ` ⚔️ ${selectedWeapon.damage} Damage`}
            {selectedWeapon.defense > 0 && ` 🛡️ +${selectedWeapon.defense}% Defense`}
          </span>
          <button className="btn-attack" onClick={() => selectedWeapon && alert('Click on enemy buildings to attack!')}>
            Click Enemy Buildings to Attack!
          </button>
        </div>
      )}
    </div>
  );
};

export default ClubWar;