// components/PortfolioSimulator.js
import React, { useState, useEffect } from 'react';
import './PortfolioSimulator.css';

const PortfolioSimulator = ({ esgScore, setEsgScore }) => {
  const [portfolio, setPortfolio] = useState({
    stocks: { amount: 0, percentage: 0, type: 'stocks', risk: 'high' },
    bonds: { amount: 0, percentage: 0, type: 'bonds', risk: 'low' },
    crypto: { amount: 0, percentage: 0, type: 'crypto', risk: 'very high' },
    mutualFunds: { amount: 0, percentage: 0, type: 'mutualFunds', risk: 'medium' },
    commodities: { amount: 0, percentage: 0, type: 'commodities', risk: 'high' },
    greenBonds: { amount: 0, percentage: 0, type: 'greenBonds', risk: 'low', esg: 'high' }
  });

  const [totalValue, setTotalValue] = useState(10000);
  const [initialInvestment, setInitialInvestment] = useState(10000);
  const [timePeriod, setTimePeriod] = useState(12); // months
  const [marketScenario, setMarketScenario] = useState('stable');
  const [compounding, setCompounding] = useState({ active: false, rate: 5, locked: false });
  const [performanceHistory, setPerformanceHistory] = useState([]);
  const [derivatives, setDerivatives] = useState({
    putOptions: 0,
    callOptions: 0,
    futures: 0
  });
  const [showDisaster, setShowDisaster] = useState(false);
  const [disasterMessage, setDisasterMessage] = useState('');

  const assetClasses = [
    { id: 'stocks', name: 'Stocks', color: '#4CAF50', icon: '📈', esg: 'medium' },
    { id: 'bonds', name: 'Bonds', color: '#2196F3', icon: '📊', esg: 'low' },
    { id: 'crypto', name: 'Cryptocurrency', color: '#FF9800', icon: '₿', esg: 'very low' },
    { id: 'mutualFunds', name: 'Mutual Funds', color: '#9C27B0', icon: '📦', esg: 'medium' },
    { id: 'commodities', name: 'Commodities', color: '#795548', icon: '🛢️', esg: 'low' },
    { id: 'greenBonds', name: 'Green Bonds', color: '#00BCD4', icon: '🌱', esg: 'very high' }
  ];

  const marketScenarios = [
    { id: 'stable', name: 'Stable Market', volatility: 0.05 },
    { id: 'volatile', name: 'Volatile Market', volatility: 0.15 },
    { id: 'crash', name: 'Market Crash', volatility: -0.30 },
    { id: 'bull', name: 'Bull Market', volatility: 0.20 },
    { id: 'recession', name: 'Recession', volatility: -0.15 }
  ];

  const derivativesOptions = [
    { id: 'putOptions', name: 'Put Options', description: 'Protect against price drops', cost: 100, effect: 'hedge' },
    { id: 'callOptions', name: 'Call Options', description: 'Bet on price increases', cost: 150, effect: 'leverage' },
    { id: 'futures', name: 'Futures', description: 'Lock in future prices', cost: 200, effect: 'stability' }
  ];

  useEffect(() => {
    calculateESGScore();
    simulateMarket();
  }, [portfolio, marketScenario, timePeriod]);

  const calculateESGScore = () => {
    let totalESG = 0;
    let totalWeight = 0;

    Object.entries(portfolio).forEach(([key, asset]) => {
      const assetInfo = assetClasses.find(a => a.id === key);
      if (assetInfo) {
        let assetESG = 0;
        switch (assetInfo.esg) {
          case 'very high': assetESG = 100; break;
          case 'high': assetESG = 80; break;
          case 'medium': assetESG = 60; break;
          case 'low': assetESG = 40; break;
          case 'very low': assetESG = 20; break;
          default: assetESG = 50;
        }
        totalESG += (asset.percentage / 100) * assetESG;
        totalWeight += asset.percentage / 100;
      }
    });

    const newESG = totalWeight > 0 ? Math.round(totalESG / totalWeight) : 75;
    setEsgScore(newESG);

    // Trigger disaster if ESG is too low
    if (newESG < 30 && Math.random() > 0.7) {
      triggerDisaster('ESG');
    }

    // Trigger disaster if portfolio is too risky
    const highRiskPercentage = portfolio.crypto.percentage + portfolio.commodities.percentage;
    if (highRiskPercentage > 50 && Math.random() > 0.8) {
      triggerDisaster('Risk');
    }
  };

  const triggerDisaster = (type) => {
    const disasters = {
      ESG: [
        "🌪️ Climate Disaster! Low ESG investments lose value.",
        "🏭 Regulatory fines for poor environmental practices.",
        "💸 Social backlash affects your portfolio returns."
      ],
      Risk: [
        "📉 Crypto market crash! High-risk assets plummet.",
        "💥 Commodity bubble bursts!",
        "🔥 High volatility wipes out gains."
      ]
    };

    const messages = disasters[type] || ["Market disruption affects your portfolio."];
    const randomMessage = messages[Math.floor(Math.random() * messages.length)];
    
    setDisasterMessage(randomMessage);
    setShowDisaster(true);

    // Apply damage to portfolio
    const damage = type === 'ESG' ? 0.15 : 0.25; // 15-25% loss
    const newTotal = totalValue * (1 - damage);
    setTotalValue(newTotal);

    setTimeout(() => {
      setShowDisaster(false);
    }, 5000);
  };

  const simulateMarket = () => {
    const scenario = marketScenarios.find(s => s.id === marketScenario);
    if (!scenario) return;

    let newTotal = initialInvestment;
    const history = [];

    // Simulate monthly returns
    for (let month = 1; month <= timePeriod; month++) {
      let monthlyReturn = 0;

      Object.entries(portfolio).forEach(([key, asset]) => {
        if (asset.percentage > 0) {
          // Base return for each asset class
          let baseReturn = 0;
          switch (key) {
            case 'stocks': baseReturn = 0.008; break;
            case 'bonds': baseReturn = 0.004; break;
            case 'crypto': baseReturn = 0.015; break;
            case 'mutualFunds': baseReturn = 0.006; break;
            case 'commodities': baseReturn = 0.007; break;
            case 'greenBonds': baseReturn = 0.005; break;
            default: baseReturn = 0.005;
          }

          // Apply market scenario effect
          let scenarioEffect = scenario.volatility * Math.random();
          
          // Apply ESG bonus for green investments
          let esgBonus = 0;
          if (key === 'greenBonds') {
            esgBonus = 0.002; // 0.2% bonus for green investments
          }

          // Apply derivative effects
          let derivativeEffect = 0;
          if (derivatives.putOptions > 0 && scenarioEffect < -0.1) {
            derivativeEffect = Math.abs(scenarioEffect) * 0.5; // Hedging effect
          }

          const assetReturn = baseReturn + scenarioEffect + esgBonus + derivativeEffect;
          const assetValue = (asset.percentage / 100) * newTotal;
          monthlyReturn += assetValue * assetReturn;
        }
      });

      // Apply compounding if active
      if (compounding.active && compounding.locked) {
        const monthlyCompounding = (compounding.rate / 12 / 100) * newTotal;
        monthlyReturn += monthlyCompounding;
      }

      newTotal += monthlyReturn;
      history.push({
        month,
        value: newTotal,
        return: monthlyReturn
      });
    }

    setTotalValue(Math.round(newTotal));
    setPerformanceHistory(history);
  };

  const allocatePercentage = (assetType, percentage) => {
    const currentTotal = Object.values(portfolio).reduce((sum, asset) => sum + asset.percentage, 0);
    const otherAssets = Object.values(portfolio).reduce((sum, asset) => 
      asset.type !== assetType ? sum + asset.percentage : sum, 0
    );

    if (otherAssets + percentage > 100) {
      alert('Total allocation cannot exceed 100%');
      return;
    }

    setPortfolio(prev => ({
      ...prev,
      [assetType]: {
        ...prev[assetType],
        percentage: percentage,
        amount: (percentage / 100) * totalValue
      }
    }));
  };

  const rebalancePortfolio = () => {
    // Simple rebalancing to target allocation
    const targetAllocation = {
      stocks: 30,
      bonds: 20,
      crypto: 10,
      mutualFunds: 20,
      commodities: 10,
      greenBonds: 10
    };

    const newPortfolio = { ...portfolio };
    Object.keys(newPortfolio).forEach(key => {
      newPortfolio[key] = {
        ...newPortfolio[key],
        percentage: targetAllocation[key] || 0,
        amount: (targetAllocation[key] / 100) * totalValue
      };
    });

    setPortfolio(newPortfolio);
    alert('Portfolio rebalanced to target allocation!');
  };

  const addToCompounding = (months) => {
    if (compounding.locked) {
      alert('Compounding vault is already locked!');
      return;
    }

    setCompounding({
      ...compounding,
      active: true,
      locked: true,
      lockPeriod: months,
      startDate: new Date().toISOString()
    });

    // Show educational message
    alert(`💰 Compounding vault locked for ${months} months! This simulates long-term retirement accounts like 401(k)s.`);
  };

  const purchaseDerivative = (type) => {
    const derivative = derivativesOptions.find(d => d.id === type);
    if (!derivative) return;

    if (totalValue < derivative.cost) {
      alert('Not enough funds to purchase this derivative!');
      return;
    }

    setDerivatives(prev => ({
      ...prev,
      [type]: prev[type] + 1
    }));

    setTotalValue(prev => prev - derivative.cost);

    alert(`Purchased ${derivative.name}! ${derivative.description}`);
  };

  const quickAllocation = (strategy) => {
    const strategies = {
      conservative: { stocks: 20, bonds: 40, crypto: 0, mutualFunds: 30, commodities: 5, greenBonds: 5 },
      balanced: { stocks: 40, bonds: 20, crypto: 10, mutualFunds: 20, commodities: 5, greenBonds: 5 },
      aggressive: { stocks: 50, bonds: 10, crypto: 20, mutualFunds: 10, commodities: 5, greenBonds: 5 },
      esgFocused: { stocks: 20, bonds: 10, crypto: 5, mutualFunds: 20, commodities: 5, greenBonds: 40 }
    };

    const allocation = strategies[strategy] || strategies.balanced;
    const newPortfolio = { ...portfolio };

    Object.keys(newPortfolio).forEach(key => {
      newPortfolio[key] = {
        ...newPortfolio[key],
        percentage: allocation[key] || 0,
        amount: ((allocation[key] || 0) / 100) * totalValue
      };
    });

    setPortfolio(newPortfolio);
    alert(`Applied ${strategy} strategy!`);
  };

  const calculateRiskMetrics = () => {
    let totalRisk = 0;
    Object.entries(portfolio).forEach(([key, asset]) => {
      let riskWeight = 0;
      switch (asset.risk) {
        case 'very high': riskWeight = 4; break;
        case 'high': riskWeight = 3; break;
        case 'medium': riskWeight = 2; break;
        case 'low': riskWeight = 1; break;
        default: riskWeight = 2;
      }
      totalRisk += (asset.percentage / 100) * riskWeight;
    });

    return {
      riskScore: Math.round(totalRisk * 25), // Scale to 0-100
      diversification: Object.values(portfolio).filter(a => a.percentage > 5).length,
      maxDrawdown: Math.min(...performanceHistory.map(h => h.return)) || 0
    };
  };

  const riskMetrics = calculateRiskMetrics();

  return (
    <div className="portfolio-simulator">
      <div className="simulator-header">
        <h2>📈 Portfolio Simulator</h2>
        <div className="simulator-stats">
          <div className="stat-card">
            <div className="stat-label">Portfolio Value</div>
            <div className="stat-value">${totalValue.toLocaleString()}</div>
            <div className="stat-change">
              {totalValue >= initialInvestment ? '📈' : '📉'} 
              ${(totalValue - initialInvestment).toLocaleString()}
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-label">ESG Score</div>
            <div className="stat-value esg-score">{esgScore}</div>
            <div className={`esg-rating ${esgScore >= 70 ? 'good' : esgScore >= 40 ? 'medium' : 'poor'}`}>
              {esgScore >= 70 ? '🌱 Excellent' : esgScore >= 40 ? '⚠️ Moderate' : '🔥 Poor'}
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Risk Score</div>
            <div className="stat-value risk-score">{riskMetrics.riskScore}</div>
            <div className={`risk-rating ${riskMetrics.riskScore <= 30 ? 'low' : riskMetrics.riskScore <= 60 ? 'medium' : 'high'}`}>
              {riskMetrics.riskScore <= 30 ? '🛡️ Low' : riskMetrics.riskScore <= 60 ? '⚖️ Medium' : '⚡ High'}
            </div>
          </div>
        </div>
      </div>

      {/* Disaster Warning */}
      {showDisaster && (
        <div className="disaster-warning">
          <div className="disaster-icon">🚨</div>
          <div className="disaster-message">{disasterMessage}</div>
          <div className="disaster-damage">Portfolio value decreased by 15-25%!</div>
        </div>
      )}

      {/* Market Controls */}
      <div className="market-controls">
        <div className="control-group">
          <label>Market Scenario:</label>
          <select 
            value={marketScenario} 
            onChange={(e) => setMarketScenario(e.target.value)}
            className="scenario-select"
          >
            {marketScenarios.map(scenario => (
              <option key={scenario.id} value={scenario.id}>
                {scenario.name} ({scenario.volatility > 0 ? '+' : ''}{scenario.volatility * 100}%)
              </option>
            ))}
          </select>
        </div>

        <div className="control-group">
          <label>Time Period: {timePeriod} months</label>
          <input 
            type="range" 
            min="1" 
            max="60" 
            value={timePeriod}
            onChange={(e) => setTimePeriod(parseInt(e.target.value))}
          />
        </div>

        <div className="quick-strategies">
          <h4>Quick Strategies:</h4>
          <div className="strategy-buttons">
            <button className="strategy-btn conservative" onClick={() => quickAllocation('conservative')}>
              🛡️ Conservative
            </button>
            <button className="strategy-btn balanced" onClick={() => quickAllocation('balanced')}>
              ⚖️ Balanced
            </button>
            <button className="strategy-btn aggressive" onClick={() => quickAllocation('aggressive')}>
              ⚡ Aggressive
            </button>
            <button className="strategy-btn esg" onClick={() => quickAllocation('esgFocused')}>
              🌱 ESG Focused
            </button>
          </div>
        </div>
      </div>

      {/* Portfolio Allocation */}
      <div className="allocation-section">
        <h3>📊 Portfolio Allocation</h3>
        <div className="allocation-grid">
          {assetClasses.map(asset => (
            <div key={asset.id} className="allocation-card">
              <div className="asset-header" style={{ borderLeftColor: asset.color }}>
                <div className="asset-icon">{asset.icon}</div>
                <div className="asset-name">{asset.name}</div>
                <div className="asset-esg" title={`ESG: ${asset.esg}`}>
                  {asset.esg === 'very high' ? '🌱🌱🌱' : 
                   asset.esg === 'high' ? '🌱🌱' : 
                   asset.esg === 'medium' ? '🌱' : '⚠️'}
                </div>
              </div>
              
              <div className="allocation-controls">
                <div className="percentage-display">
                  <span className="percentage-value">{portfolio[asset.id].percentage}%</span>
                  <span className="amount-value">
                    ${Math.round((portfolio[asset.id].percentage / 100) * totalValue).toLocaleString()}
                  </span>
                </div>
                
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={portfolio[asset.id].percentage}
                  onChange={(e) => allocatePercentage(asset.id, parseInt(e.target.value))}
                  className="allocation-slider"
                  style={{ background: asset.color }}
                />
                
                <div className="allocation-buttons">
                  <button onClick={() => allocatePercentage(asset.id, Math.min(100, portfolio[asset.id].percentage + 10))}>
                    +10%
                  </button>
                  <button onClick={() => allocatePercentage(asset.id, Math.max(0, portfolio[asset.id].percentage - 10))}>
                    -10%
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="allocation-summary">
          <div className="total-allocation">
            Total: {Object.values(portfolio).reduce((sum, asset) => sum + asset.percentage, 0)}%
          </div>
          <button className="btn-rebalance" onClick={rebalancePortfolio}>
            🔄 Rebalance Portfolio
          </button>
        </div>
      </div>

      {/* Derivatives Section */}
      <div className="derivatives-section">
        <h3>🎯 Advanced Tools: Derivatives</h3>
        <div className="derivatives-grid">
          {derivativesOptions.map(derivative => (
            <div key={derivative.id} className="derivative-card">
              <div className="derivative-header">
                <div className="derivative-icon">
                  {derivative.effect === 'hedge' ? '🛡️' : 
                   derivative.effect === 'leverage' ? '🎯' : '⚖️'}
                </div>
                <div className="derivative-name">{derivative.name}</div>
              </div>
              <div className="derivative-description">{derivative.description}</div>
              <div className="derivative-cost">Cost: 🎫 {derivative.cost}</div>
              <div className="derivative-owned">Owned: {derivatives[derivative.id]}</div>
              <button 
                className="btn-buy-derivative"
                onClick={() => purchaseDerivative(derivative.id)}
              >
                Purchase
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Compounding Vault */}
      <div className="compounding-section">
        <h3>💰 Compounding Vault</h3>
        <div className={`vault-card ${compounding.locked ? 'locked' : 'unlocked'}`}>
          <div className="vault-icon">{compounding.locked ? '🔒' : '🔓'}</div>
          <div className="vault-details">
            <div className="vault-status">
              Status: {compounding.locked ? 'Locked' : 'Available'}
            </div>
            <div className="vault-rate">
              Simulated APY: {compounding.rate}%
            </div>
            {compounding.locked && (
              <div className="vault-info">
                <div>Lock Period: {compounding.lockPeriod} months</div>
                <div>Projected Value: ${Math.round(totalValue * Math.pow(1 + compounding.rate/100, compounding.lockPeriod/12)).toLocaleString()}</div>
              </div>
            )}
          </div>
          
          <div className="vault-actions">
            {!compounding.locked ? (
              <>
                <button className="btn-lock" onClick={() => addToCompounding(12)}>
                  🔒 Lock for 12 months
                </button>
                <button className="btn-lock" onClick={() => addToCompounding(36)}>
                  🔒 Lock for 36 months
                </button>
                <button className="btn-lock" onClick={() => addToCompounding(60)}>
                  🔒 Lock for 60 months
                </button>
              </>
            ) : (
              <div className="locked-message">
                <div className="educational-tip">
                  💡 This simulates long-term investment vehicles like 401(k)s or IRAs where your money grows tax-free over time.
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Performance Chart */}
      <div className="performance-section">
        <h3>📈 Performance History</h3>
        <div className="performance-chart">
          {performanceHistory.length > 0 ? (
            <div className="chart-container">
              <div className="chart-bars">
                {performanceHistory.slice(-12).map((monthData, index) => (
                  <div key={index} className="chart-bar-container">
                    <div className="chart-bar-label">M{monthData.month}</div>
                    <div className="chart-bar-wrapper">
                      <div 
                        className={`chart-bar ${monthData.return >= 0 ? 'positive' : 'negative'}`}
                        style={{ 
                          height: `${Math.min(100, Math.abs(monthData.return) / totalValue * 10000)}%` 
                        }}
                      ></div>
                    </div>
                    <div className="chart-bar-value">
                      {monthData.return >= 0 ? '+' : ''}{Math.round(monthData.return)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="no-data">Simulate market to see performance data</div>
          )}
        </div>
        
        <div className="performance-metrics">
          <div className="metric-card">
            <div className="metric-label">Total Return</div>
            <div className={`metric-value ${totalValue >= initialInvestment ? 'positive' : 'negative'}`}>
              {((totalValue - initialInvestment) / initialInvestment * 100).toFixed(2)}%
            </div>
          </div>
          <div className="metric-card">
            <div className="metric-label">Best Month</div>
            <div className="metric-value positive">
              +{performanceHistory.length > 0 ? Math.max(...performanceHistory.map(h => h.return)).toFixed(0) : 0}
            </div>
          </div>
          <div className="metric-card">
            <div className="metric-label">Worst Month</div>
            <div className="metric-value negative">
              {performanceHistory.length > 0 ? Math.min(...performanceHistory.map(h => h.return)).toFixed(0) : 0}
            </div>
          </div>
          <div className="metric-card">
            <div className="metric-label">Diversification</div>
            <div className="metric-value">{riskMetrics.diversification}/6 assets</div>
          </div>
        </div>
      </div>

      {/* Educational Tips */}
      <div className="educational-tips">
        <h4>💡 Investment Concepts Demonstrated:</h4>
        <div className="tips-grid">
          <div className="tip-card">
            <div className="tip-icon">🌱</div>
            <div className="tip-content">
              <strong>ESG Investing</strong>: Low ESG scores can trigger disasters, showing the importance of sustainable investing.
            </div>
          </div>
          <div className="tip-card">
            <div className="tip-icon">🛡️</div>
            <div className="tip-content">
              <strong>Risk Management</strong>: High-risk allocations (crypto/commodities) can lead to significant losses during market downturns.
            </div>
          </div>
          <div className="tip-card">
            <div className="tip-icon">💰</div>
            <div className="tip-content">
              <strong>Compounding</strong>: The vault demonstrates how money grows exponentially over time, simulating retirement accounts.
            </div>
          </div>
          <div className="tip-card">
            <div className="tip-icon">🎯</div>
            <div className="tip-content">
              <strong>Derivatives</strong>: Options and futures can hedge against losses or amplify gains, but at a cost.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PortfolioSimulator;