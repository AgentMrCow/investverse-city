// components/SkillTree.js - Skill Tree Component
import React, { useState } from 'react';
import './SkillTree.css';

const SkillTree = ({ userLevel }) => {
  const [unlockedSkills, setUnlockedSkills] = useState(['basics', 'budgeting']);
  const [availablePoints, setAvailablePoints] = useState(5);

  const skillTrees = {
    basics: {
      title: '💰 Investment Basics',
      icon: '💰',
      skills: [
        { id: 'basics', name: 'Basic Concepts', level: 1, cost: 0, unlocked: true },
        { id: 'stocks', name: 'Stock Market', level: 2, cost: 1, requires: 'basics' },
        { id: 'bonds', name: 'Bonds & Fixed Income', level: 3, cost: 2, requires: 'stocks' },
        { id: 'etfs', name: 'ETFs & Mutual Funds', level: 4, cost: 3, requires: 'bonds' }
      ]
    },
    advanced: {
      title: '📈 Advanced Strategies',
      icon: '📈',
      skills: [
        { id: 'portfolio', name: 'Portfolio Theory', level: 5, cost: 3, requires: 'etfs' },
        { id: 'derivatives', name: 'Derivatives', level: 6, cost: 4, requires: 'portfolio' },
        { id: 'crypto', name: 'Crypto Assets', level: 7, cost: 4, requires: 'portfolio' },
        { id: 'alternative', name: 'Alternative Investments', level: 8, cost: 5, requires: 'portfolio' }
      ]
    },
    esg: {
      title: '🌱 Sustainable Investing',
      icon: '🌱',
      skills: [
        { id: 'esg-basics', name: 'ESG Fundamentals', level: 3, cost: 2 },
        { id: 'impact', name: 'Impact Investing', level: 5, cost: 3, requires: 'esg-basics' },
        { id: 'green-bonds', name: 'Green Bonds', level: 6, cost: 4, requires: 'impact' },
        { id: 'esg-reporting', name: 'ESG Reporting', level: 8, cost: 5, requires: 'green-bonds' }
      ]
    },
    risk: {
      title: '⚡ Risk Management',
      icon: '⚡',
      skills: [
        { id: 'risk-basics', name: 'Risk Basics', level: 2, cost: 1 },
        { id: 'diversification', name: 'Diversification', level: 3, cost: 2, requires: 'risk-basics' },
        { id: 'hedging', name: 'Hedging Strategies', level: 5, cost: 3, requires: 'diversification' },
        { id: 'options', name: 'Options Trading', level: 7, cost: 4, requires: 'hedging' }
      ]
    }
  };

  const unlockSkill = (skillId) => {
    const skill = Object.values(skillTrees)
      .flatMap(tree => tree.skills)
      .find(s => s.id === skillId);

    if (!skill) return;
    
    if (unlockedSkills.includes(skillId)) {
      alert('Skill already unlocked!');
      return;
    }

    if (skill.requires && !unlockedSkills.includes(skill.requires)) {
      alert(`Requires ${skill.requires} to be unlocked first!`);
      return;
    }

    if (availablePoints >= skill.cost) {
      setUnlockedSkills([...unlockedSkills, skillId]);
      setAvailablePoints(availablePoints - skill.cost);
      alert(`🎉 Unlocked ${skill.name}!`);
    } else {
      alert('Not enough skill points!');
    }
  };

  return (
    <div className="skill-tree">
      <div className="skill-tree-header">
        <h2>🌳 Skill Tree - Level {userLevel}</h2>
        <div className="skill-points">
          <span className="points-badge">🎯 Available Points: {availablePoints}</span>
          <span className="unlocked-badge">🔓 Unlocked: {unlockedSkills.length} skills</span>
        </div>
      </div>

      <div className="tree-navigation">
        <p>Click on skills to unlock them. Complete Q&A challenges to earn skill points!</p>
      </div>

      <div className="trees-container">
        {Object.entries(skillTrees).map(([key, tree]) => (
          <div key={key} className="tree-section">
            <h3 className="tree-title">
              <span className="tree-icon">{tree.icon}</span>
              {tree.title}
            </h3>
            <div className="skills-path">
              {tree.skills.map((skill, index) => {
                const isUnlocked = unlockedSkills.includes(skill.id);
                const canUnlock = !isUnlocked && 
                  (!skill.requires || unlockedSkills.includes(skill.requires)) &&
                  availablePoints >= skill.cost &&
                  userLevel >= skill.level;

                return (
                  <div 
                    key={skill.id}
                    className={`skill-node ${isUnlocked ? 'unlocked' : ''} ${canUnlock ? 'available' : 'locked'}`}
                    onClick={() => canUnlock && unlockSkill(skill.id)}
                    title={skill.name}
                  >
                    <div className="node-icon">
                      {isUnlocked ? '✅' : canUnlock ? '🔓' : '🔒'}
                    </div>
                    <div className="node-info">
                      <div className="node-name">{skill.name}</div>
                      <div className="node-level">Lvl {skill.level}</div>
                      <div className="node-cost">{skill.cost} point{skill.cost !== 1 ? 's' : ''}</div>
                    </div>
                    {index < tree.skills.length - 1 && (
                      <div className={`path-line ${unlockedSkills.includes(tree.skills[index + 1]?.id) ? 'active' : ''}`}></div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <div className="skill-benefits">
        <h3>🏆 Current Benefits</h3>
        <div className="benefits-grid">
          {unlockedSkills.includes('stocks') && (
            <div className="benefit-card">
              <div className="benefit-icon">📈</div>
              <div className="benefit-text">+10% Token rewards from stock-related Q&A</div>
            </div>
          )}
          {unlockedSkills.includes('esg-basics') && (
            <div className="benefit-card">
              <div className="benefit-icon">🌱</div>
              <div className="benefit-text">ESG Shield: Reduces disaster damage by 20%</div>
            </div>
          )}
          {unlockedSkills.includes('diversification') && (
            <div className="benefit-card">
              <div className="benefit-icon">🛡️</div>
              <div className="benefit-text">Portfolio Defense: +15% building health</div>
            </div>
          )}
          {unlockedSkills.includes('options') && (
            <div className="benefit-card">
              <div className="benefit-icon">🎯</div>
              <div className="benefit-text">Options Power-up: Critical hit chance +10%</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SkillTree;