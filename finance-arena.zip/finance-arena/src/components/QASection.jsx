// components/QASection.js - Q&A Component
import React, { useState, useEffect } from 'react';
import './QASection.css';

const QASection = ({ addTokens }) => {
  const [questions, setQuestions] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [userAnswer, setUserAnswer] = useState('');
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState(null);
  const [streak, setStreak] = useState(0);

  const sampleQuestions = [
    {
      id: 1,
      question: "What is diversification in investment?",
      options: [
        "Putting all money in one stock",
        "Spreading investments across different assets",
        "Investing only in bonds",
        "Keeping money in savings account"
      ],
      correctAnswer: 1,
      category: "Basic Investing",
      difficulty: "Easy",
      tokenReward: 10
    },
    {
      id: 2,
      question: "Which of these is a high-risk investment?",
      options: [
        "Government bonds",
        "Savings account",
        "Cryptocurrency",
        "Certificate of Deposit"
      ],
      correctAnswer: 2,
      category: "Risk Management",
      difficulty: "Medium",
      tokenReward: 15
    },
    {
      id: 3,
      question: "What does ESG stand for?",
      options: [
        "Economic Social Governance",
        "Environmental Social Governance",
        "Enterprise Stock Growth",
        "Equity Security Guarantee"
      ],
      correctAnswer: 1,
      category: "Sustainable Investing",
      difficulty: "Easy",
      tokenReward: 10
    },
    {
      id: 4,
      question: "What is compound interest?",
      options: [
        "Interest on initial principal only",
        "Interest calculated on principal + accumulated interest",
        "Fixed interest rate",
        "Interest paid monthly"
      ],
      correctAnswer: 1,
      category: "Wealth Building",
      difficulty: "Medium",
      tokenReward: 20
    }
  ];

  useEffect(() => {
    setQuestions(sampleQuestions);
    
    if (timeLeft > 0 && !showResult) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0) {
      handleTimeout();
    }
  }, [timeLeft, showResult]);

  const handleAnswer = (selectedIndex) => {
    setUserAnswer(selectedIndex);
    const correct = selectedIndex === questions[currentQuestion].correctAnswer;
    setIsCorrect(correct);
    
    if (correct) {
      const newStreak = streak + 1;
      setStreak(newStreak);
      const bonus = newStreak >= 3 ? 5 : 0; // Streak bonus
      const reward = questions[currentQuestion].tokenReward + bonus;
      setScore(score + reward);
      addTokens(reward);
    } else {
      setStreak(0);
    }
    
    setShowResult(true);
  };

  const handleTimeout = () => {
    setIsCorrect(false);
    setShowResult(true);
    setStreak(0);
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setTimeLeft(30);
      setShowResult(false);
      setIsCorrect(null);
      setUserAnswer('');
    } else {
      // Complete daily challenge
      const dailyBonus = 50;
      setScore(score + dailyBonus);
      addTokens(dailyBonus);
      alert(`🎉 Daily Challenge Complete! Bonus: ${dailyBonus} tokens!`);
    }
  };

  const submitQuestion = () => {
    // Function for users to submit their own questions
    const newQuestion = {
      question: document.getElementById('new-question').value,
      options: [
        document.getElementById('option1').value,
        document.getElementById('option2').value,
        document.getElementById('option3').value,
        document.getElementById('option4').value
      ],
      correctAnswer: parseInt(document.getElementById('correct-answer').value),
      category: document.getElementById('category').value,
      difficulty: document.getElementById('difficulty').value
    };
    
    // In real app, send to backend
    alert('Question submitted for review! Earn 5 tokens if approved.');
    addTokens(5);
  };

  if (!questions.length) return <div>Loading questions...</div>;

  return (
    <div className="qa-section">
      <div className="qa-header">
        <h2>📚 Daily Q&A Challenge</h2>
        <div className="qa-stats">
          <div className="timer">⏱️ {timeLeft}s</div>
          <div className="streak">🔥 Streak: {streak}</div>
          <div className="score">🏆 Score: {score}</div>
        </div>
      </div>

      <div className="qa-progress">
        <div className="progress-bar">
          <div 
            className="progress" 
            style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
          ></div>
        </div>
        <span>Question {currentQuestion + 1} of {questions.length}</span>
      </div>

      <div className="question-card">
        <div className="question-meta">
          <span className="category-badge">{questions[currentQuestion].category}</span>
          <span className="difficulty-badge">{questions[currentQuestion].difficulty}</span>
          <span className="reward-badge">🎫 +{questions[currentQuestion].tokenReward}</span>
        </div>
        
        <h3 className="question-text">{questions[currentQuestion].question}</h3>
        
        <div className="options-grid">
          {questions[currentQuestion].options.map((option, index) => (
            <button
              key={index}
              className={`option-btn ${
                showResult 
                  ? index === questions[currentQuestion].correctAnswer 
                    ? 'correct' 
                    : userAnswer === index 
                      ? 'incorrect' 
                      : ''
                  : ''
              }`}
              onClick={() => !showResult && handleAnswer(index)}
              disabled={showResult}
            >
              <span className="option-letter">{String.fromCharCode(65 + index)}</span>
              {option}
            </button>
          ))}
        </div>

        {showResult && (
          <div className="result-section">
            <div className={`result-message ${isCorrect ? 'correct' : 'incorrect'}`}>
              {isCorrect ? '✅ Correct!' : '❌ Time\'s up!'}
              {isCorrect && streak >= 3 && <span className="streak-bonus"> +5 streak bonus!</span>}
            </div>
            <button className="btn-next" onClick={nextQuestion}>
              {currentQuestion < questions.length - 1 ? 'Next Question →' : 'Complete Daily Challenge'}
            </button>
          </div>
        )}
      </div>

      {/* User Question Submission */}
      <div className="submit-question">
        <h3>💡 Submit Your Question</h3>
        <div className="submit-form">
          <input type="text" id="new-question" placeholder="Enter your question..." />
          <input type="text" id="option1" placeholder="Option A" />
          <input type="text" id="option2" placeholder="Option B" />
          <input type="text" id="option3" placeholder="Option C" />
          <input type="text" id="option4" placeholder="Option D" />
          <select id="correct-answer">
            <option value="0">A</option>
            <option value="1">B</option>
            <option value="2">C</option>
            <option value="3">D</option>
          </select>
          <select id="category">
            <option>Basic Investing</option>
            <option>Risk Management</option>
            <option>Sustainable Investing</option>
            <option>Wealth Building</option>
          </select>
          <select id="difficulty">
            <option>Easy</option>
            <option>Medium</option>
            <option>Hard</option>
          </select>
          <button className="btn-submit" onClick={submitQuestion}>Submit Question</button>
        </div>
      </div>
    </div>
  );
};

export default QASection;