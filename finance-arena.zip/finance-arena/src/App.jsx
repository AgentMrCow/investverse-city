// App.js - Main Application Structure
import React, { useState } from 'react';
import QASection from './components/QASection.jsx';
import ClubWar from './components/ClubWar.jsx';
import SkillTree from './components/SkillTree.jsx';
import PortfolioSimulator from './components/PortfolioSimulator.jsx';

function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [userTokens, setUserTokens] = useState(1000);
  const [userLevel, setUserLevel] = useState(1);
  const [esgScore, setEsgScore] = useState(75);

  const tabs = [
    { id: 'home', label: '🏠 Home', icon: '🏠' },
    { id: 'qa', label: '📚 Q&A Challenge', icon: '📚' },
    { id: 'club', label: '⚔️ Club War', icon: '⚔️' },
    { id: 'skills', label: '🌳 Skill Tree', icon: '🌳' },
    { id: 'portfolio', label: '📈 Portfolio Sim', icon: '📈' },
    { id: 'market', label: '🛍️ Token Market', icon: '🛍️' }
  ];

  const addTokens = (amount) => {
    setUserTokens(prev => prev + amount);
  };

  return (
    <div className="App">
      {/* Header */}
      <header className="app-header">
        <div className="header-left">
          <h1>💰 Smart Finance Arena</h1>
          <div className="user-stats">
            <span className="token-badge">🎫 {userTokens} Tokens</span>
            <span className="level-badge">⭐ Lvl {userLevel}</span>
            <span className="esg-badge">🌱 ESG: {esgScore}</span>
          </div>
        </div>
        <div className="user-profile">
          <div className="avatar">👤</div>
          <span>Finance Explorer</span>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="main-nav">
        {tabs.map(tab => (
          <button
            key={tab.id}
            className={`nav-btn ${activeTab === tab.id ? 'active' : ''}`}
            onClick={() => setActiveTab(tab.id)}
          >
            <span className="nav-icon">{tab.icon}</span>
            {tab.label}
          </button>
        ))}
      </nav>

      {/* Main Content */}
      <main className="main-content">
        {activeTab === 'qa' && <QASection addTokens={addTokens} />}
        {activeTab === 'club' && <ClubWar userTokens={userTokens} />}
        {activeTab === 'skills' && <SkillTree userLevel={userLevel} />}
        {activeTab === 'portfolio' && <PortfolioSimulator esgScore={esgScore} setEsgScore={setEsgScore} />}
        
        {activeTab === 'home' && (
          <div className="dashboard">
            <h2>🎯 Today's Missions</h2>
            <div className="mission-grid">
              <div className="mission-card">
                <h3>📖 Daily Q&A (2/5)</h3>
                <p>Complete 5 questions to earn 50 tokens</p>
                <div className="progress-bar">
                  <div className="progress" style={{ width: '40%' }}></div>
                </div>
              </div>
              <div className="mission-card">
                <h3>⚔️ Club War Prep</h3>
                <p>Next war starts in: 2h 15m</p>
                <button className="btn-primary">Prepare Strategy</button>
              </div>
              <div className="mission-card">
                <h3>📈 Portfolio Check</h3>
                <p>Your ESG score: {esgScore}</p>
                <button className="btn-secondary">Rebalance</button>
              </div>
            </div>

            <div className="leaderboard-section">
              <h3>🏆 Monthly Leaderboard</h3>
              <table className="leaderboard-table">
                <thead>
                  <tr>
                    <th>Rank</th>
                    <th>Player</th>
                    <th>Tokens</th>
                    <th>Level</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="top-player">
                    <td>🥇 1</td>
                    <td>CryptoKing</td>
                    <td>12,450</td>
                    <td>25</td>
                  </tr>
                  <tr>
                    <td>🥈 2</td>
                    <td>FinancePro</td>
                    <td>10,200</td>
                    <td>22</td>
                  </tr>
                  <tr>
                    <td>🥉 3</td>
                    <td>RiskMaster</td>
                    <td>9,800</td>
                    <td>21</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'market' && (
          <div className="token-market">
            <h2>🛍️ Token Marketplace</h2>
            <div className="market-items">
              <div className="market-card">
                <div className="item-image" style={{ background: 'linear-gradient(45deg, #ff6b6b, #ee5a24)' }}>⚔️</div>
                <h3>Legendary Sword</h3>
                <p>Damage: +50% in Club Wars</p>
                <div className="item-price">🎫 500 Tokens</div>
                <button className="btn-buy">Buy Now</button>
              </div>
              <div className="market-card">
                <div className="item-image" style={{ background: 'linear-gradient(45deg, #4ecdc4, #44a08d)' }}>🛡️</div>
                <h3>ESG Shield</h3>
                <p>Protects against disasters</p>
                <div className="item-price">🎫 300 Tokens</div>
                <button className="btn-buy">Buy Now</button>
              </div>
              <div className="market-card">
                <div className="item-image" style={{ background: 'linear-gradient(45deg, #ffd166, #ff9e00)' }}>🎲</div>
                <h3>Gacha Pull</h3>
                <p>Random item (Common to Legendary)</p>
                <div className="item-price">🎫 100 Tokens</div>
                <button className="btn-buy">Pull Now</button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Token Notification */}
      {userTokens > 0 && (
        <div className="token-notification">
          <span>🎫 You have {userTokens} tokens available!</span>
        </div>
      )}
    </div>
  );
}

export default App;